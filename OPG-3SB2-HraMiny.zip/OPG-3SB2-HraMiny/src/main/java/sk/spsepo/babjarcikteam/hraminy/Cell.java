package sk.spsepo.babjarcikteam.hraminy;

import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.Objects;

public class Cell extends Button {

    private int row;
    private int col;
    private int neighborsCount;
    private boolean hasMine;
    private ImageView flagImageView;
    private ImageView mineImageView;
    private State state;

    //konkretne stavy bunky
    public enum State{
        FLAG, REVEALED, HIDDEN
    }

    //Zakladne nastavenieeenie bunky
    public Cell(int row, int col) {
        this.row = row;
        this.col = col;
        this.neighborsCount = 0;
        this.hasMine = false;
        this.state = State.HIDDEN;
        this.setPrefSize(40, 40);

        Image flagImage = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/sk/spsepo/babjarcikteam/hraminy/img/flagbyai.png")));
        this.flagImageView = new ImageView(flagImage);
        this.flagImageView.setFitWidth(20);
        this.flagImageView.setFitHeight(20);

        Image mineImage = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/sk/spsepo/babjarcikteam/hraminy/img/bombbyai.png")));
        this.mineImageView = new ImageView(mineImage);
        this.mineImageView.setFitWidth(20);
        this.mineImageView.setFitHeight(20);

        updateStyle();
    }

    //Pocet riadkov
    public int getRow() {
        return row;
    }

    //Pocet stlpcov
    public int getCol() {
        return col;
    }

    //Ma alebo nema minu
    public boolean hasMine() {
        return hasMine;
    }

    //Nastavenie bunke minu
    public void setMine(boolean hasMine) {
        this.hasMine = hasMine;
        updateStyle();
    }

    //Je alebo nieje REVEALED
    public boolean isRevealed() {
        return state == State.REVEALED;
    }

    //Odkry bunku
    public void reveal() {
        if (state != State.REVEALED) {
            state = State.REVEALED;
            updateStyle();
        }
    }

    //Je alebo nie je oznacena
    public boolean isFlagged() {
        return state == State.FLAG;
    }

    //Nastavenie alebo odstran vlajku
    public void toggleFlag() {
        if (state == State.FLAG) {
            state = State.HIDDEN;
        } else {
            state = State.FLAG;
        }
        updateStyle();
    }

    //Pocet susediacich bomb
    public int getNeighborsCount() {
        return neighborsCount;
    }

    //Nastavenie pocet susediacich bomb
    public void setNeighborsCount(int neighborsCount) {
        this.neighborsCount = neighborsCount;
        updateStyle();
    }

    //Nastav vzhlad
    private void updateStyle() {
        if (state == State.REVEALED) {
            if (hasMine) {
                setGraphic(mineImageView);
                setStyle("-fx-background-color: lightgray;");
            } else {
                setGraphic(null);
                setText(neighborsCount > 0 ? String.valueOf(neighborsCount) : "");
                setStyle("-fx-background-color: lightgray;");
            }
        } else {
            setText("");
            if (state == State.FLAG) {
                setGraphic(flagImageView);
                setStyle("-fx-background-color: lightgray;");
            } else {
                setGraphic(null);
                setStyle("-fx-background-color: gray;");
            }
        }
    }
}
