package sk.spsepo.babjarcikteam.hraminy;

public class SpustaciaTrieda {
    public static void main(String[] args) {
        MineSweeper.main(args);
    }
}
