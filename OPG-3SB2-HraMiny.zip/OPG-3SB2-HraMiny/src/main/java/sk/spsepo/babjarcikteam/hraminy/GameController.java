package sk.spsepo.babjarcikteam.hraminy;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.GridPane;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;

import java.net.URL;
import java.util.Objects;
import java.util.Random;
import java.util.ResourceBundle;

public class GameController implements Initializable {

    @FXML
    private GridPane gridPane;
    @FXML
    private Label statusLabel;
    @FXML
    private Spinner<Integer> rowsSpinner;
    @FXML
    private Spinner<Integer> colsSpinner;
    @FXML
    private Spinner<Integer> minesSpinner;
    @FXML
    private Label minesLeftLabel;
    @FXML
    private Label timerLabel;
    @FXML
    private Button smileyButton;

    private Cell[][] cells;
    private int rows;
    private int cols;
    private int mines;
    private int revealedCells;
    private int remainingMines;
    private boolean gameEnded;
    private Timeline timeline;
    private int timeElapsed;
    private ImageView smileyImageView;
    private ImageView sadSmileyImageView;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //Obrazky
        Image smileyImage = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/sk/spsepo/babjarcikteam/hraminy/img/happybyai.png")));
        Image sadSmileyImage = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/sk/spsepo/babjarcikteam/hraminy/img/unhappybyai.png")));

        //Nastavenie rozmerov pre obrazky
        smileyImageView = new ImageView(smileyImage);
        smileyImageView.setFitWidth(40);
        smileyImageView.setFitHeight(40);

        sadSmileyImageView = new ImageView(sadSmileyImage);
        sadSmileyImageView.setFitWidth(40);
        sadSmileyImageView.setFitHeight(40);

        smileyButton.setGraphic(smileyImageView);

        smileyButton.setOnAction(e -> resetGame());

        //Nastavenie vstupnych poli
        rowsSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(5, 30, 10));
        colsSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(5, 30, 10));
        minesSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 50, 10));

        //Reset hry
        resetGame();
    }

    //Reset hry
    private void resetGame() {
        rows = rowsSpinner.getValue();
        cols = colsSpinner.getValue();
        mines = minesSpinner.getValue();
        revealedCells = 0;
        remainingMines = mines;
        gameEnded = false;
        timeElapsed = 0;

        minesLeftLabel.setText("Míny: " + remainingMines);
        timerLabel.setText("Čas: " + timeElapsed);
        smileyButton.setGraphic(smileyImageView); 

        //Nastavenie casovej osi
        if (timeline != null) {
            timeline.stop();
        }

        timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            timeElapsed++;
            timerLabel.setText("Čas: " + timeElapsed);
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

        cells = new Cell[rows][cols];
        gridPane.getChildren().clear();

        //Vytvorenie hracej plochy
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                Cell cell = new Cell(row, col);
                cells[row][col] = cell;
                gridPane.add(cell, col, row);

                cell.setOnMouseClicked(event -> {
                    if (gameEnded) {
                        return;
                    }

                    if (event.getButton() == MouseButton.PRIMARY) {
                        revealCell(cell);
                    } else if (event.getButton() == MouseButton.SECONDARY) {
                        toggleFlag(cell);
                    }
                });
            }
        }

        //rozmiestnenie min
        placeMines();
        updateNeighborsCount();
        statusLabel.setText("Pokračujte...");
    }

    //Rozmiestni miny
    private void placeMines() {
        Random random = new Random();
        int placedMines = 0;

        while (placedMines < mines) {
            int row = random.nextInt(rows);
            int col = random.nextInt(cols);

            if (!cells[row][col].hasMine()) {
                cells[row][col].setMine(true);
                placedMines++;
            }
        }
    }

    //Obnovi pocet susediacich min
    private void updateNeighborsCount() {
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                if (!cells[row][col].hasMine()) {
                    int minesCount = 0;
                    for (int r = Math.max(0, row - 1); r <= Math.min(rows - 1, row + 1); r++) {
                        for (int c = Math.max(0, col - 1); c <= Math.min(cols - 1, col + 1); c++) {
                            if (cells[r][c].hasMine()) {
                                minesCount++;
                            }
                        }
                    }
                    cells[row][col].setNeighborsCount(minesCount);
                }
            }
        }
    }

    //Odkry bunku
    private void revealCell(Cell cell) {
        if (cell.isRevealed() || cell.isFlagged()) {
            return;
        }

        cell.reveal();
        revealedCells++;

        if (cell.hasMine()) {
            statusLabel.setText("Prehrali ste!");
            gameEnded = true;
            revealAllMines();
            smileyButton.setGraphic(sadSmileyImageView);
            timeline.stop();
            return;
        }

        if (cell.getNeighborsCount() == 0) {
            revealAdjacentCells(cell);
        }

        //Ukoncenie hry
        if (revealedCells == rows * cols - mines) {
            statusLabel.setText("Vyhrali ste!");
            gameEnded = true;
            timeline.stop();
        }
    }

    //Odhali vacsiu plochu ak ziadna zo susediacich buniek nema v sebe minu
    private void revealAdjacentCells(Cell cell) {
        int row = cell.getRow();
        int col = cell.getCol();

        for (int r = Math.max(0, row - 1); r <= Math.min(rows - 1, row + 1); r++) {
            for (int c = Math.max(0, col - 1); c <= Math.min(cols - 1, col + 1); c++) {
                if (cells[r][c] != cell && !cells[r][c].isRevealed() && !cells[r][c].isFlagged()) {
                    revealCell(cells[r][c]);
                }
            }
        }
    }

    //Nastavenie vlajky
    private void toggleFlag(Cell cell) {
        if (!cell.isRevealed()) {
            if (!cell.isFlagged()) {
                cell.toggleFlag();
                remainingMines--;
            } else {
                cell.toggleFlag();
                remainingMines++;
            }
            if (remainingMines < 0) {
                remainingMines = 0;
            }
            minesLeftLabel.setText("Míny: " + remainingMines);
        }
    }

    //Odkryje miny
    private void revealAllMines() {
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                if (cells[row][col].hasMine()) {
                    cells[row][col].reveal();
                }
            }
        }
    }
}
