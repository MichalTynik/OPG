module sk.spsepo.babjarcikteam.hraminy {
    requires javafx.controls;
    requires javafx.fxml;


    opens sk.spsepo.babjarcikteam.hraminy to javafx.fxml;
    exports sk.spsepo.babjarcikteam.hraminy;
}