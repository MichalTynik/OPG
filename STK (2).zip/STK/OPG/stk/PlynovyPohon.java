package OPG.stk;

public interface PlynovyPohon {
    void meranieTlakuPlynuVZasobniku();
}
