package OPG.stk;

public interface BenzinovyPohon {
    void meranieTlakuPaliva();
    void meranieTlakuOleja();
    void meranieTeplotyMotora();
}
