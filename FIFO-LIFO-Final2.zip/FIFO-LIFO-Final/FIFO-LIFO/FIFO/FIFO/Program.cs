﻿
using FIFO;

FIFOClass fifo = new FIFOClass(10);
ConsoleKeyInfo cskey = new ConsoleKeyInfo();
while (cskey.Key != ConsoleKey.C)
{
               Console.WriteLine("Ovladanie Enter => Vyber/Vloz\nMedzernik => Vypis");
               cskey = Console.ReadKey();
               Console.WriteLine("------------");
               if (cskey.Key == ConsoleKey.Enter)
               {
                              Random rnd = new Random();
                              int i = rnd.Next(1, 3);
                              if (i == 1)
                              {
                                             Console.WriteLine("vklad");
                                             fifo.Put();
                              }
                              else{
                                             Console.WriteLine("vyber");
                                             fifo.Get();
                              }

               }

               if (cskey.Key == ConsoleKey.Spacebar)
               {
                              fifo.Print();
               }    
}

/// <summary>
/// Trieda ktora sa stara o text piesne
/// </summary>
public class FIFOClass
{
               Music music = new Music();
               readonly string _path = "KaraokeText";
               int _head;
               int _tail;
               string[] buffer;
               

               /// <summary>
               /// Konstruktor pre triedu FIFO
               /// </summary>
               /// <param name="capacity">Velkost buffera</param>
               public FIFOClass(int capacity)
               {
                              buffer = new string[capacity];
                              _tail = -1;
               }

               /// <summary>
               /// Vypise _head, _tail a buffer
               /// </summary>
               public void Print()
               {
                              Console.WriteLine("[{0}], tail = {1}, head = {2}", string.Join(", ", buffer), _tail, _head);
               }

               /// <summary>
               /// Data posle z internetu / Vlozi slovo z txt do buffera
               /// </summary>
               public void Put()
               {
                              if (buffer.Length  != _head)
                              {
                                             string newData = music.Lyrics();
                                             buffer[_head] = newData;
                                             if (_head == buffer.Length - 1)
                                                            _head = 0;
                                             else
                                                            _head++;
                                             if (_tail == -1)
                                                            _tail = 0;
                              }
                              else
                              {
                                             Console.WriteLine("DATA LOST");
                              }
                              
               }

               /// <summary>
               /// Vypise slovo z buffera
               /// </summary>
               public void Get()
               {
                              if (_tail != -1)
                              {
                                             string result = buffer[_tail];
                                             if (_tail == buffer.Length - 1) _tail = 0;
                                             else _tail++;
                                             if (_tail == _head)
                                             {
                                                            _tail = -1;
                                                            _head = 0;
                                             }
                                             Console.WriteLine(result);
                              }
                              else
                              {
                                             Console.WriteLine("DATA LOST");
                              }
               }
}