module sk.spsepo.babjarciktynik.kalkulacka {
    requires javafx.controls;
    requires javafx.fxml;


    opens sk.spsepo.babjarciktynik.kalkulacka to javafx.fxml;
    exports sk.spsepo.babjarciktynik.kalkulacka;
}