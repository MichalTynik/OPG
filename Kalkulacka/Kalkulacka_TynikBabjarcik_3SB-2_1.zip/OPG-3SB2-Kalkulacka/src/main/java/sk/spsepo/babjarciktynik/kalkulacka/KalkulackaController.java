package sk.spsepo.babjarciktynik.kalkulacka;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

public class KalkulackaController {
    
    @FXML
    private TextField topField;

    @FXML
    private TextField bottomField;

    private StringBuilder vyraz = new StringBuilder();
    private double cislo1 = 0;
    private double cislo2 = 0;
    private String operator = "";

    @FXML
    private void zistiBtn(ActionEvent event) {
        Button btn = (Button) event.getSource();
        String buttonText = btn.getText();

        switch (buttonText) {
            case "CL":
                clear();
                break;
            case "+":
            case "-":
            case "*":
            case "/":
                if (!vyraz.toString().isEmpty()) {
                    cislo1 = Double.parseDouble(vyraz.toString());
                    operator = buttonText;
                    vyraz.append(" ").append(operator).append(" ");
                    topField.setText(vyraz.toString());
                }
                break;
            case "=":
                if (!vyraz.toString().isEmpty()) {
                    String[] parts = vyraz.toString().split("\\s+");
                    if (parts.length == 3) {
                        cislo2 = Double.parseDouble(parts[2]);
                        calculate();
                    }
                }
                break;
            default:
                vyraz.append(buttonText);
                topField.setText(vyraz.toString());
                break;
        }
    }

    private void calculate() {
        double vysledok = 0;
        switch (operator) {
            case "+":
                vysledok = cislo1 + cislo2;
                break;
            case "-":
                vysledok = cislo1 - cislo2;
                break;
            case "*":
                vysledok = cislo1 * cislo2;
                break;
            case "/":
                if (cislo2 != 0) {
                    vysledok = cislo1 / cislo2;
                } else {
                    vysledok = Double.POSITIVE_INFINITY; 
                }
                break;
        }
        bottomField.setText(Double.toString(vysledok));
        vyraz.setLength(0);
        vyraz.append(vysledok);
        cislo1 = vysledok;
    }

    private void clear() {
        vyraz.setLength(0);
        cislo1 = 0;
        cislo2 = 0;
        operator = "";
        topField.clear();
        bottomField.clear();
    }
}