package sk.spsepo.babjarciktynik.kalkulacka;

public class SpustacaTrieda {
    public static void main(String[] args) {
        KalkulackaAplikacia.main(args);
    }
}

