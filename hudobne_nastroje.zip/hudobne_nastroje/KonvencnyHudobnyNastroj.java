package hudobne_nastroje;

interface KonvencnyNastroj {
    void hraj(String nota);
    int LUBOVOLENE_CISLO = 50;
}