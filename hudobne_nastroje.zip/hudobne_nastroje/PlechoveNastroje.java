package hudobne_nastroje;

interface PlechoveNastroje extends KonvencnyNastroj {
    void zatrub();
}