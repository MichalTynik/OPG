package hudobne_nastroje;

class Pikola extends DychovyNastroj {
    @Override
    public void hraj(String nota) {
        System.out.println("Pikola hrá: "+ nota);
    }
}