package hudobne_nastroje;

interface ElektronickeNastroje {
    void syntetizuj(String nota);
}