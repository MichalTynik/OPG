package OPG.stk;

public class TechnickaKontrola {
    public static void main(String[] args) {
        MajitelAuta[] majitelia = {
                new MajitelAuta("Pavol Pavlovic", "Prešov", "AH85479"),
                new MajitelAuta("Milan Milanovic", "Košice", "BG85559"),
                new MajitelAuta("Peter Petrovic", "Humenne", "CG78477"),
                new MajitelAuta("Denisa Denisova", "Michalovce", "AH66677"),
                new MajitelAuta("Jana Janova", "Prešov", "AH77777"),
                new MajitelAuta("Natalia Krcmarova", "Košice", "BG88888"),
                new MajitelAuta("Michal Michalovic", "Humenne", "CG99999"),
                new MajitelAuta("Denis Denisovic", "Michalovce", "AH33333")
        };

        auto[] auta_zakladna_kontrola = {
                new BenzinoveAuto("12565874", "Renault Megan", "biela"),
                new BenzinoveAuto("12565874", "Renault Clio", "cervena"),
                new ElektroAuto("1256555", "Citroän C3", "karamelova"),
                new ElektroAuto("1256555", "Citroän C4", "strieborna"),
                new HybridneAuto("1266874", "Toyota Hybrid", "čierna"),
                new HybridneAuto("1266874", "Toyota Yaris", "biela"),
                new PlynoveAuto("12777874", "Dacia Logan", "červena"),
                new PlynoveAuto("12777874", "Dacia SW", "zelena")
        };

        BenzinovyPohon[] benzinoveAuta = {
                (BenzinovyPohon) auta_zakladna_kontrola[0],
                (BenzinovyPohon) auta_zakladna_kontrola[1]
        };

        ElektrickyPohon[] elektrickeAuta = {
                (ElektrickyPohon) auta_zakladna_kontrola[2],
                (ElektrickyPohon) auta_zakladna_kontrola[3]
        };

        HybridnyPohon[] hybridneAuta = {
                (HybridnyPohon) auta_zakladna_kontrola[4],
                (HybridnyPohon) auta_zakladna_kontrola[5]
        };

        PlynovyPohon[] plynoveAuta = {
                (PlynovyPohon) auta_zakladna_kontrola[6],
                (PlynovyPohon) auta_zakladna_kontrola[7]
        };

        System.out.println("-".repeat(50));
        System.out.println("Technicka Kontrola - Babjarčík Dávid III.SB 2.Skupina");
        System.out.println("Výpis:");
        System.out.println("-".repeat(50));

        DiagnostZakladFunkcieAuta(auta_zakladna_kontrola, majitelia);

        DiagnostSpecialFunkcieAuta(benzinoveAuta, elektrickeAuta, hybridneAuta, plynoveAuta);
    }

    private static void DiagnostZakladFunkcieAuta(auto[] auta, MajitelAuta[] majitelia) {
        for (int i = 0; i < auta.length; i++) {
            MajitelAuta majitel = majitelia[i];
            auto autoObj = auta[i];

            System.out.println(majitel.getMeno() + " " + majitel.getMesto() + " " + majitel.getCisloOP());
            System.out.println(autoObj.getVINCislo());
            System.out.println(autoObj.getZnacka());
            System.out.println(autoObj.getFarba());
            autoObj.DiagnostTlakBrzdKvapalina();
            autoObj.DiagnostTlakPneumatiky();
            autoObj.DiagnostBezpecnostSystem();
            System.out.println("-".repeat(30));
        }
    }

    private static void DiagnostSpecialFunkcieAuta(BenzinovyPohon[] benzinoveAuta,
                                                          ElektrickyPohon[] elektrickeAuta,
                                                          HybridnyPohon[] hybridneAuta,
                                                          PlynovyPohon[] plynoveAuta) {
        DiagnostFunkcii(benzinoveAuta);
        DiagnostFunkcii(elektrickeAuta);
        DiagnostFunkcii(hybridneAuta);
        DiagnostFunkcii(plynoveAuta);
    }

    private static void DiagnostFunkcii(BenzinovyPohon[] auta) {
        for (BenzinovyPohon auto : auta) {
            auto.MeranieTeplotyMotora();
            auto.MeranieTlakOleja();
            auto.MeranieTlakPaliva();
            System.out.println("-".repeat(30));
        }
    }

    private static void DiagnostFunkcii(ElektrickyPohon[] auta) {
        for (ElektrickyPohon auto : auta) {
            auto.MeranieNapatiaAkumulatv();
            System.out.println("-".repeat(30));
        }
    }

    private static void DiagnostFunkcii(HybridnyPohon[] auta) {
        for (HybridnyPohon auto : auta) {
            auto.MeranieNapatiaAkumulatv();
            auto.MeranieTeplotyAkumulatorov();
            auto.MeranieTlakOleja();
            auto.MeranieTlakPaliva();
            System.out.println("-".repeat(30));
        }
    }

    private static void DiagnostFunkcii(PlynovyPohon[] auta) {
        for (PlynovyPohon auto : auta) {
            auto.MeranieTlakuPlynuVZasobniku();
            System.out.println("-".repeat(30));
        }
    }
}
