package OPG.stk;
public class MajitelAuta {
    private final String Meno;
    private final String Mesto;
    private final String CisloOP;

    public MajitelAuta(String Meno, String Mesto, String CisloOP) {
        this.Meno = Meno;
        this.Mesto = Mesto;
        this.CisloOP = CisloOP;
    }

    public String getMeno() {
        return Meno;
    }

    public String getMesto() {
        return Mesto;
    }

    public String getCisloOP() {
        return CisloOP;
    }
}
