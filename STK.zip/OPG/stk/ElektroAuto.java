package OPG.stk;

public class ElektroAuto extends auto implements ElektrickyPohon {
    public ElektroAuto(String VINCislo, String Znacka, String Farba) {
        super(VINCislo, Znacka, Farba);
    }

    @Override
    public void DiagnostTlakBrzdKvapalina() {
        System.out.println("Tlak brzdovej kvapaliny: 18 MPa");
    }

    @Override
    public void DiagnostTlakPneumatiky() {
        System.out.println("Tlak v pneumatikách: 2.9 MPa");
    }

    @Override
    public void MeranieNapatiaAkumulatv() {
        System.out.println("Napätie akumulatorov: 200 V");
    }
}
