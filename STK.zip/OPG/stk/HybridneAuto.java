package OPG.stk;

class HybridneAuto extends auto implements HybridnyPohon {
    public HybridneAuto(String VINCislo, String Znacka, String Farba) {
        super(VINCislo, Znacka, Farba);
    }

    @Override
    public void DiagnostTlakBrzdKvapalina() { System.out.println("Tlak brzdovej kvapaliny: 13.5 MPa");
    }

    @Override
    public void DiagnostTlakPneumatiky() { System.out.println("Tlak v pneumatikách: 2,9 MPa");
    }

    @Override
    public void MeranieTlakOleja() { System.out.println("Tlak paliva: 15 MPa");
    }

    @Override
    public void MeranieTlakPaliva() { System.out.println("Tlak oleja: 3 Bar");
    }

    @Override
    public void MeranieTeplotyAkumulatorov() {
        System.out.println("Teplota akumulátorov: 45 °C");
    }

    @Override
    public void MeranieNapatiaAkumulatv() {
        System.out.println("Napätie akumulatorov: 150 V");
    }

    @Override
    public void MeranieTeplotyMotora() {

    }
}