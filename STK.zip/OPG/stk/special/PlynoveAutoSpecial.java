package OPG.stk.special;

import OPG.stk.PlynovyPohon;
import OPG.stk.auto;

class PlynoveAutoSpecial extends auto implements PlynovyPohon {
    public PlynoveAutoSpecial(String VINCislo, String Znacka, String Farba) {
        super(VINCislo, Znacka, Farba);
    }

    @Override
    public void MeranieTlakuPlynuVZasobniku() {
        System.out.println("Tlak plynového zásobníka: 100 bar");
    }
}