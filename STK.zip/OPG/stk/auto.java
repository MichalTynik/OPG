package OPG.stk;

public class auto {
    private boolean ASR;
    private boolean ABS;
    private boolean AirBag;

    private final String VINCislo;
    private final String Znacka;
    private final String Farba;

    public auto(String VINCislo, String Znacka, String Farba) {
        this.VINCislo = VINCislo;
        this.Znacka = Znacka;
        this.Farba = Farba;
    }
    public boolean isASR() {
        return ASR;
    }

    public boolean isABS() {
        return ABS;
    }

    public boolean isAirBag() {
        return AirBag;
    }

    protected void setASR(boolean ASR) {
        this.ASR = ASR;
    }

    protected void setABS(boolean ABS) {
        this.ABS = ABS;
    }
    public String getVINCislo() {
        return VINCislo;
    }

    public String getZnacka() {
        return Znacka;
    }

    public String getFarba() {
        return Farba;
    }
    protected void setAirBag(boolean AirBag) {
        this.AirBag = AirBag;
    }

    public void DiagnostTlakPneumatiky() {
        System.out.println("Tlak v pneumatikách: 2.2 Bar");
    }

    public void DiagnostTlakBrzdKvapalina() {
        System.out.println("Tlak brzdovej kvapaliny: 12 MPa");
    }


    public void DiagnostBezpecnostSystem() {
        AirBag = true;
        ASR = true;
        ABS = true;
        System.out.println("Stav AirBagu vodiča: " + AirBag);
        System.out.println("Stav systému regulácie prešmykovania ASR: " + ASR);
        System.out.println("Stav antiblokovacieho systému ABS: " + ABS);

    }
}