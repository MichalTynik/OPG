package OPG.stk;

public interface BenzinovyPohon {
    void MeranieTlakPaliva();
    void MeranieTlakOleja();
    void MeranieTeplotyMotora();
}
