package OPG.stk;

public interface HybridnyPohon extends ElektrickyPohon, BenzinovyPohon {
    void MeranieTeplotyAkumulatorov();
}
