package OPG.stk;

class PlynoveAuto extends auto implements PlynovyPohon {
    public PlynoveAuto(String VINCislo, String Znacka, String Farba) {
        super(VINCislo, Znacka, Farba);
    }

    @Override
    public void DiagnostTlakPneumatiky() { System.out.println("Tlak v pneumatikách: 2,4 MPa");
    }

    @Override
    public void MeranieTlakuPlynuVZasobniku() {
        System.out.println("Meranie tlaku plynu v zásobníku: 100 bar");
    }
}