package OPG.stk;

public interface ElektrickyPohon {
    void MeranieNapatiaAkumulatv();
}
